#include <stdio.h>
#include <math.h>
#include <stdbool.h>

#define C 1
#define N 100000
#define A 69069
const long long M = pow(2,31);

#define X0 15
#define p 7
#define q 3

// 2 zadania 100000 liczb, całkowite od 0 do N-1
// 1 - 2.2
// 2 - 2.6

unsigned int gen_liniowy(long long Xn) {
	return (A * Xn + C) % M;
}

bool btAt(int var, int pos) {
	int s = 8 * sizeof(int);
	return ((var>>pos)<<(s-pos))>>s;
}

unsigned int gen_reg_shift(unsigned int Xn) {
	unsigned int ret_val = 0;
	Xn = Xn >> 26;
	for( int i = p; i < sizeof(int)*8 + p; i++) {
		bool bt = btAt(Xn, i - p)^btAt(Xn, i - q);
		ret_val = ret_val<<1;
		ret_val += bt;
	}
	
	return ret_val;
}

long long binToDec(bool* bin, int size) {
	long long dec = 0;
	int pow2 = 1;
	for( int i = 0; i < size; i++, pow2 = pow2<<1)
		dec += bin[size - i - 1]*pow2;
		
	return dec;
}

int main() {
	unsigned int X_l[N], X_s[N];
	unsigned int count_l[10], count_s[10];
	for( int i = 0; i < 10; i++)
		count_l[i] = count_s[i] = 0;
	 
	X_l[0] = X0;
	X_s[0] = 0b1001011;
	for(int i = 1; i < N; i++)
		X_l[i] = gen_liniowy(X_l[i-1]);
	
	X_s[1] = gen_reg_shift(X_s[0]);
	for(int i = 2; i < N; i++) {
		X_s[i] = gen_reg_shift(X_s[i-1]);
		printf("%u\n", X_s[i]);
	}
	
	
	for( int i = 0; i < N; i++) {
		count_l[X_l[i]%10]++;
		count_s[X_s[i]%10]++;
	}
	printf("zad1:\n");
	for(int i = 0; i < 10; i++)
		printf("%d\n", count_l[i]);
	
	
	printf("zad2:\n");
	for(int i = 0; i < 10; i++)
		printf("%d\n", count_s[i]);


	return 0;
}
